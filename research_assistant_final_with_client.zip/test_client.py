
from utils.client import get_inference_client

client = get_inference_client()
print("✅ Client initialized:", client)
